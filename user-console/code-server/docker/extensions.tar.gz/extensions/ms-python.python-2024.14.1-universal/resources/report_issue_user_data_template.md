-   Python version (& distribution if applicable, e.g. Anaconda): {0}
-   Type of virtual environment used (e.g. conda, venv, virtualenv, etc.): {1}
-   Value of the `python.languageServer` setting: {2}

<details>
<summary>User Settings</summary>
<p>

```
{3}{4}
```
</p>
</details>

<details>
<summary>Installed Extensions</summary>

|Extension Name|Extension Id|Version|
|---|---|---|
{5}
</details>
